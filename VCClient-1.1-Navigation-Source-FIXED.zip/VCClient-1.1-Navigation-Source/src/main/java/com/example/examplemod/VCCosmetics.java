package com.example.examplemod;
import net.minecraft.client.Minecraft;
import net.minecraft.client.model.ModelBase;
import net.minecraft.client.model.ModelRenderer;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.client.event.RenderPlayerEvent;
import net.minecraftforge.client.event.RenderWorldLastEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import org.lwjgl.opengl.GL11;

/** Client-only wing renderer. Companion options are represented by local status text for now. */
public class VCCosmetics extends ModelBase {
 public boolean wings=false,dog=false,wither=false,parrot=false;
 private boolean applied=false;
 private final Minecraft mc=Minecraft.getMinecraft();
 private final ResourceLocation texture=new ResourceLocation("vcclient","textures/wings.png");
 private final ModelRenderer wing;
 public VCCosmetics(){
  setTextureOffset("bone",0,0);setTextureOffset("skin",0,4);
  wing=new ModelRenderer(this,"wing");wing.setTextureSize(32,32);wing.setRotationPoint(-2F,0F,0F);
  // Use the unnamed addBox overload: named boxes can dereference a missing texture-offset entry in this setup.
  wing.setTextureOffset(0,0);wing.addBox(-10F,-1F,-1F,10,2,2);
  wing.setTextureOffset(0,4);wing.addBox(-10F,0F,0F,10,1,8);
 }
 public void apply(){applied=true;}
 @SubscribeEvent public void render(RenderPlayerEvent.Post e){
  EntityPlayer p=e.entityPlayer;if(!applied||!wings||p!=mc.thePlayer||p.isInvisible())return;
  float t=(System.currentTimeMillis()%1400L)/1400F*(float)Math.PI*2F;
  GL11.glPushMatrix();
  try{
   GL11.glTranslatef(0F,0F,0F);GL11.glRotatef(180F+p.renderYawOffset,0F,1F,0F);
   GL11.glTranslatef(0F,-1.1F,0.2F);mc.getTextureManager().bindTexture(texture);
   GL11.glScalef(-1F,-1F,1F);
   for(int i=0;i<2;i++){wing.rotateAngleX=-1.15F-(float)Math.cos(t)*.18F;wing.rotateAngleY=.2F+(float)Math.sin(t)*.3F;wing.rotateAngleZ=.2F;wing.render(.0625F);GL11.glScalef(-1F,1F,1F);}
  }finally{GL11.glColor4f(1F,1F,1F,1F);GL11.glPopMatrix();}
 }
 @SubscribeEvent public void status(RenderWorldLastEvent e){ /* no fake entities spawned in multiplayer */ }
}
