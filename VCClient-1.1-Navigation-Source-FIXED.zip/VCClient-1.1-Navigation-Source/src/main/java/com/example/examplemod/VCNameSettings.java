package com.example.examplemod;
import java.io.*; import java.util.Properties;
public final class VCNameSettings {
 public static String nickname="VC Player"; private static File file;
 public static void load(File f){file=f;Properties p=new Properties();if(f.isFile())try(FileInputStream in=new FileInputStream(f)){p.load(in);nickname=p.getProperty("nickname",nickname);}catch(Exception ignored){}}
 public static void save(){if(file==null)return;Properties p=new Properties();p.setProperty("nickname",nickname);try(FileOutputStream out=new FileOutputStream(file)){p.store(out,"VC Client");}catch(Exception ignored){}}
 private VCNameSettings(){}
}